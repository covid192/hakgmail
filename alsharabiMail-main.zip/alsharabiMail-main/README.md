


[◾] Instalação da ferramenta<br>

• pkg update<br>
• pkg install python<br>
• pkg install python2<br>
• pkg install python3<br>
• pkg install git<br>
• git clone https://github.com/sadamshr3be/alsharabiMail


• cd alsharabiMail


• chmod +x sadamalsharabi.py<br>
• python3 sadamalsharabi.py<br><br><br>

 
TErmux
المدونة الخاصة في الشروح
https://sadamalsharabi.blogspot.com/?m=1

حسابي علـّۓ. اليوتيوب
https://www.youtube.com/channel/UC6KWVWMUn210EJYDyUHQhKQ
حسابي https://github.com/sadamshr3be
حسابي @sadam_alsharabi
الجروب @alsharabii ,
https://t.me/termuxalsharabi
